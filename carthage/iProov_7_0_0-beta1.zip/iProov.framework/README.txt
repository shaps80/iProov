Loco ios export: iOS Localizable.strings
Project: iProov
Release: Working copy
Exported at: Tue, 22 Jan 2019 12:20:17 +0000
Exported by: Jonathan Ellis